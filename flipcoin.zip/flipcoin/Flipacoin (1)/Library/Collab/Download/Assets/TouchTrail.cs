﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchTrail : MonoBehaviour
{
    TrailRenderer _myTrailRenderer;
    Transform _myTrns;
    public float smooth = 10;
    Camera mainCam;

    void Start()
    {
        mainCam = Camera.main;
        _myTrailRenderer = GetComponent<TrailRenderer>();
        _myTrns = transform;
        _myTrailRenderer.enabled = false;

    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            //show trail
            _myTrailRenderer.enabled = true;
            //lock to touch
            UpdateTouch(Input.mousePosition);
        }

        if (Input.GetMouseButton(0)) {
            //lock to touch
            UpdateTouch(Input.mousePosition);
        }

        if (Input.GetMouseButtonUp(0)) {
            //hide trail 
           // _myTrailRenderer.enabled = false;
           // _myTrailRenderer.Clear();
            //move out
        }
    }

    void UpdateTouch(Vector3 thisPos) {
        Vector3 point = mainCam.ScreenToWorldPoint(new Vector3(thisPos.x, thisPos.y, mainCam.nearClipPlane + 0.3f));
        _myTrns.position = point;
    }
}
