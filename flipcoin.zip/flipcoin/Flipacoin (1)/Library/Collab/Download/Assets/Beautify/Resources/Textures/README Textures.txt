Sample pack of textures for Beautify. Feel free to use them in your project or replace with your own.
LUTSepia texture generated using the public method Beautify.instance.GenerateSepiaLUT()

grungeVignette texture derived work from original work by Kjpargeter - Freepik.com. Licensed by Creative Commons-Atribution.
Other textures included in this folder are Public Domain.

