﻿namespace Com.LuisPedroFonseca.ProCamera2D
{
    public enum UpdateType
    {
        LateUpdate,
        FixedUpdate,
        ManualUpdate
    }
}