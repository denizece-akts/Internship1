﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlickManager : MonoBehaviour
{
    public CoinManager coinMngr;
    Vector3 swipeStartPos;
    Vector3 swipeEndPos;
    public float swipeMultiplier = 1f;

    void Start()
    {

    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) {
            //swipe start
            swipeStartPos = Input.mousePosition;
        }

        if (Input.GetMouseButton(0)) {
        
        }

        if (Input.GetMouseButtonUp(0)) {
            //swipe end
            swipeEndPos = Input.mousePosition;
            SwipeEvent(swipeEndPos - swipeStartPos);
        }
    }

    void SwipeEvent(Vector2 finalVector) {
            coinMngr.FlickCoin(finalVector * swipeMultiplier);
    }

}
