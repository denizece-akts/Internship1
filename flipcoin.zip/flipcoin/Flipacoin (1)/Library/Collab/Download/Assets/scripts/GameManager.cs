﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    private void Awake()
    {
        Application.targetFrameRate = 60;
    }

    public void CoinDropped() {
        //game lost
        ReloadLevel();
    }

    public void CoinBowled() {
        //game won finished level
        //ReloadLevel();
    }
    void ReloadLevel() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }


    public void LoadMainMenu() {
        SceneManager.LoadScene("001_MainMenu");
    }

    public void DoubleCombo() { }

    public void TripleCombo()
    {

    }

    private void OnEnable()
    {
        instance = this;
    }

    private void OnDisable()
    {
        instance = null;
    }

}
