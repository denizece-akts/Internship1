﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CoinManager : MonoBehaviour
{


    public float MaximumX = -5;
    public float MinimumX = -10;

    public float MaximumY = 13;
    public float MinimumY = 5;

    public float MaximumZ = -117;
    public float MinimumZ = -119;
   


    public float Hiz = 0;
    Vector3 discInitialPosition;
    Quaternion discInitialRotation; 

    public Vector3 offset; 
    public Vector3 position; 
    public Vector3 centreOfGravity; 

    public TMPro.TextMeshProUGUI text; 
    public Rigidbody Disc;

    int moveableCount = 3;

    public void FlickCoin(Vector2 vector2) 
    {
        if(moveableCount <= 0) { return; }
        moveableCount--;

        if(moveableCount == 1) {
            GameManager.instance.DoubleCombo();
        }

        if (moveableCount == 0)
        {
            GameManager.instance.TripleCombo();
        }

        float xPos = Mathf.Clamp(vector2.x * 0.5f, MinimumX, MaximumX);
        float yPos = Mathf.Clamp(vector2.y * 0.4f, MinimumY, MaximumY);
        float zPos = Mathf.Clamp(vector2.magnitude / 5, MinimumZ,MaximumZ);

        Vector3 realVector = new Vector3(xPos,yPos,zPos);
        text.text = vector2.ToString();
        //Disc.AddForceAtPosition(realVector * 0.5f, this.transform.position - ForceAddPosition.position);
        Disc.AddForceAtPosition(realVector * 1.5f, this.transform.position - new Vector3(0, 0, 0.2f)); 

    }


    public void Start()
    {

    }

    private void Awake()
    {
        discInitialPosition = this.transform.position;
        discInitialRotation = this.transform.rotation;

    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag == "GroundCube") {
            moveableCount = 3;
        }

        if (collision.collider.tag == "FinishBowl")
        {
            moveableCount = 0;
            //game ended with success
            GameManager.instance.CoinBowled();
        }

        if(collision.collider.tag == "BottomBorder") {
            //game lost
            GameManager.instance.CoinDropped();
        }
    }

    //private void Update()
    //{
    //    if (Input.GetKey(KeyCode.R))
    //    {
    //        this.transform.position = discInitialPosition;
    //        this.transform.rotation = discInitialRotation;
    //        var discRigidBody = this.GetComponent<Rigidbody>();
    //        discRigidBody.ResetInertiaTensor();
    //        discRigidBody.velocity = Vector3.zero;
    //        discRigidBody.angularVelocity = Vector3.zero;





    //    }
    //}


}
