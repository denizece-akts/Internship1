﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    public float hiz = 0;
    public Rigidbody Coin;
    Transform cointTrns;
    Transform _myTrns;
    Vector3 currentVec = Vector3.zero;

    private void Start()
    {
        _myTrns = transform;
        cointTrns = Coin.transform;
    }
    void LateUpdate()
    {
        currentVec = Coin.transform.position;
        currentVec = new Vector3(cointTrns.position.x, _myTrns.position.y, _myTrns.position.z);
        //_myTrns.position += Coin.velocity * Time.deltaTime;

        _myTrns.position = currentVec;
    }
}
