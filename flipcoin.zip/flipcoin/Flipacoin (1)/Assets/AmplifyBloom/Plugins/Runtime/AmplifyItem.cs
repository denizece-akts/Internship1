﻿// Amplify Bloom - Advanced Bloom Post-Effect for Unity
// Copyright (c) Amplify Creations, Lda <info@amplify.pt>
namespace AmplifyBloom
{
	interface IAmplifyItem
	{
		void Destroy();
	}
}
