﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour {

    public Rigidbody rb;
    Vector3 myVector;
    float speed = 2.0f;
	void Start () {
        myVector = new Vector3(0.0f, 0.0f, 5.0f);
        rb.GetComponent<Rigidbody>();
	}
	
	
	void Update () {
        rb.velocity = myVector * speed;
    }
}
