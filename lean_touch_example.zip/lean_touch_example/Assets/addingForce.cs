﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class addingForce : MonoBehaviour
{
    public Rigidbody rb;
    bool var = false;
    int count = 1;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
        
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "yer")
        {
            if (count == 1)
            {
                rb.AddForce(25f, 500f, 0);
                var = true;
                count = count +1;
            }
            else if (count == 2)
            {
                rb.AddForce(-50f, 500f, 0);
                var = false;
                count = count +1;
            }
            else
            {
                if (var == true)
                {
                    rb.AddForce(-50f, 500f, 0);
                    var = false;
                }
                else
                {
                    rb.AddForce(50f, 500f, 0);
                    var = true;
                }
            }
        }
        
        
        
        
    }
}
