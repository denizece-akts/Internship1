﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button : MonoBehaviour
{
    string first = "";

    void Start()
    {
        
    }

    void Update()
    {
        if ((Input.touchCount > 0) && (Input.GetTouch(0).phase == TouchPhase.Began))
        {
            Ray raycast = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
            RaycastHit raycastHit;
            if (Physics.Raycast(raycast, out raycastHit))
            {
                //Debug.Log("Something Hit");

                if (raycastHit.collider.CompareTag("Button"))
                {

                    // Debug.Log("Button tapped");
                    if ("Red" == raycastHit.collider.material.name)
                    {

                    }
                    else if ("Yellow" == raycastHit.collider.material.name)
                    {

                    }
                    else if ("Blue" == raycastHit.collider.material.name)
                    {

                    }
                    else if ("Blue" == raycastHit.collider.material.name && "Red" == raycastHit.collider.material.name)
                    {

                    }
                    else if ("Blue" == raycastHit.collider.material.name && "Yellow" == raycastHit.collider.material.name)
                    {

                    }
                    else if ("Red" == raycastHit.collider.material.name && "Yellow" == raycastHit.collider.material.name)
                    {

                    }


                }
            }
        }
    }
}
